// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"or4r":[function(require,module,exports) {
var global = arguments[3];
/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

},{}],"WEtf":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// device sniffing for mobile
var isMobile = {
  android: function android() {
    return navigator.userAgent.match(/Android/i);
  },
  blackberry: function blackberry() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  ios: function ios() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  opera: function opera() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  windows: function windows() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function any() {
    return isMobile.android() || isMobile.blackberry() || isMobile.ios() || isMobile.opera() || isMobile.windows();
  }
};
var _default = isMobile;
exports.default = _default;
},{}],"hZBy":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.select = select;
exports.selectAll = selectAll;
exports.find = find;
exports.removeClass = removeClass;
exports.addClass = addClass;
exports.hasClass = hasClass;
exports.jumpTo = jumpTo;

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

// DOM helper functions
// public
function select(selector) {
  return document.querySelector(selector);
}

function selectAll(selector) {
  var parent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return _toConsumableArray(parent.querySelectorAll(selector));
}

function find(el, selector) {
  return _toConsumableArray(el.querySelectorAll(selector));
}

function removeClass(el, className) {
  if (el.classList) el.classList.remove(className);else el.className = el.className.replace(new RegExp("(^|\\b)".concat(className.split(' ').join('|'), "(\\b|$)"), 'gi'), ' ');
}

function addClass(el, className) {
  if (el.classList) el.classList.add(className);else el.className = "".concat(el.className, " ").concat(className);
}

function hasClass(el, className) {
  if (el.classList) return el.classList.contains(className);
  return new RegExp("(^| )".concat(className, "( |$)"), 'gi').test(el.className);
}

function jumpTo(el, offset) {
  offset = offset || 0;
  var top = el.getBoundingClientRect().top + offset;
  var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  var destY = scrollTop + top;
  window.scrollTo(0, destY);
}
},{}],"U9xJ":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = linkFix;

var _dom = require("./dom");

/**
 * Fixes target blanks links
 */
function linkFix() {
  var links = (0, _dom.selectAll)("[target='_blank']");
  links.forEach(function (link) {
    return link.setAttribute("rel", "noopener");
  });
}
},{"./dom":"hZBy"}],"WtE3":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var $section = d3.select('.guessMovement');
var $guess__container = $section.select('.guess__figure');
var $guess__svg = $guess__container.select('svg');
var $instruction2 = $guess__container.select('.instruction2');
var $warningMsg = $guess__container.select('.warningMsg');
var $interpretText = $guess__container.select('.interpretText');
var $submitBtn = $section.select('.submitBtn');
var $answer__container = $section.select('.answer__figure');
var $answer__svg = $answer__container.select('svg');
var $brush;
var $bars;
var $guess__vis;
var $answer__vis;
var $answer__bars;
var answerData = [{
  levels: 0,
  share: 0.6
}, {
  levels: 1,
  share: 11.1
}, {
  levels: 2,
  share: 44.2
}, {
  levels: 3,
  share: 29.5
}, {
  levels: 4,
  share: 14.5
}];
var guessData = [{
  levels: 0,
  share: 10
}, {
  levels: 1,
  share: 10
}, {
  levels: 2,
  share: 10
}, {
  levels: 3,
  share: 10
}, {
  levels: 4,
  share: 10
}]; // dimensions

var margin = {
  top: 20,
  bottom: 50,
  left: 46,
  right: 0
};
var width = 0;
var height = 0; // scales

var scaleX = d3.scaleBand().domain([0, 1, 2, 3, 4]).paddingInner(0.2).paddingOuter(0.6);
var scaleY = d3.scaleLinear().domain([0, 100]); // console.log($guess__container.node().offsetWidth, $guess__container.node().offsetHeight)

function setup() {
  // set up chart
  width = $guess__container.node().offsetWidth - margin.left - margin.right;
  height = $guess__container.node().offsetHeight - margin.top - margin.bottom;
  scaleX.range([0, width]);
  scaleY.range([height, 0]);
  $guess__vis = $guess__svg.attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', 'translate(' + margin.left + ',' + margin.top + ')'); // add axes

  $guess__vis.append('g').attr('class', 'axis axis--x').attr('transform', 'translate(0,' + height + ')').call(d3.axisBottom(scaleX)).append('text').attr('class', 'axisTitle').attr('x', width / 2).attr('y', margin.bottom - 2).text('Furthest Quintiles Moved').style('fill', '#000');
  $guess__vis.append('g').attr('class', 'axis axis--y').attr('transform', 'translate(-' + margin.left + ', 0)').call(d3.axisRight(scaleY).ticks(5).tickFormat(function (d) {
    return d === 100 ? d + '% of families' : d + '%';
  }).tickSize(width + margin.left)).selectAll('text').attr('x', 0).attr('dy', 14).style('text-anchor', 'start'); // set up brushes for user-dragged bars

  $brush = d3.brushY().extent(function (d, i) {
    return [[scaleX(d.levels), 0], [scaleX(d.levels) + scaleX.bandwidth(), height]];
  }).on('brush', brushMove).on('end', brushEnd);
  $bars = $guess__vis.selectAll('.brush').data(guessData).enter().append('g').attr('class', 'brush').append('g').call($brush).call($brush.move, function (d) {
    return [d.share, 0].map(scaleY);
  }) // this actually draws the "bars"
  .call(function (g) {
    return g.select('.overlay').datum({
      type: 'selection'
    }).on('mousedown touchstart', resizeBar);
  });
  d3.selectAll(".selection").style("fill", "#124653").style("fill-opacity", "0.8"); // get rid of handle at the bottom of the bars

  $guess__vis.selectAll('.handle--s').remove(); // change cursor from the move one to regular auto

  $guess__vis.selectAll('.selection').attr('cursor', 'auto');
  $guess__vis.selectAll('.overlay').attr('cursor', 'auto'); // disable ability to completely redraw the bar anywhere within its lane
  // $guess__vis.selectAll('.overlay').attr('pointer-events', 'none');
  // set up answer graph

  $answer__vis = $guess__svg.append('g').attr('transform', 'translate(' + margin.left + ',' + margin.top + ')').attr('class', 'answer noDisplay');
  $answer__bars = $answer__vis.selectAll('.answerBar').data(answerData).enter().append('g');
  $answer__bars.append('rect').attr('class', 'answerBar').attr('x', function (d) {
    return scaleX(d.levels);
  }).attr('y', function (d) {
    return height;
  }).attr('width', scaleX.bandwidth()).attr('height', 0);
  $answer__bars.append('text').attr('class', 'answerBarLabel').attr('x', function (d) {
    return scaleX(d.levels) + scaleX.bandwidth() / 2;
  }).attr('y', function (d) {
    return scaleY(d.share) - 10;
  }).text(function (d) {
    return d.share + '%';
  }).style('opacity', 0);
}

function resize() {
  // get new dimensions of the container element
  width = $guess__container.node().offsetWidth - margin.left - margin.right;
  height = width < 470 ? width * 0.7 - margin.top - margin.bottom : width * 0.54 - margin.top - margin.bottom; // height = $guess__container.node().offsetHeight - margin.top - margin.bottom;
  // update scales

  scaleX.range([0, width]);
  scaleY.range([height, 0]); // resize chart

  $guess__svg.attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom); // resize axes

  $guess__vis.selectAll('.axis.axis--x').attr('transform', 'translate(0,' + height + ')').call(d3.axisBottom(scaleX)).select('.axisTitle').attr('x', width / 2).attr('y', margin.bottom - 2);
  $guess__vis.selectAll('.axis.axis--y').attr('transform', 'translate(-' + margin.left + ', 0)').call(d3.axisRight(scaleY).ticks(5).tickFormat(function (d) {
    return d === 100 ? d + '% of families' : d + '%';
  }).tickSize(width + margin.left)).selectAll('text').attr('x', 0); // resize brushes

  $brush.extent(function (d, i) {
    return [[scaleX(d.levels), 0], [scaleX(d.levels) + scaleX.bandwidth(), height]];
  });
  $bars.call($brush).call($brush.move, function (d) {
    return [d.share, 0].map(scaleY);
  }); // resize answer bars and labels
  // first determine if the answer is revealed or not - this affects what height to set the bars at

  var answerShown = !$answer__vis.classed('noDisplay');
  $answer__bars.selectAll('.answerBar').attr('x', function (d) {
    return scaleX(d.levels);
  }).attr('y', function (d) {
    return answerShown ? scaleY(d.share) : height;
  }).attr('width', scaleX.bandwidth()).attr('height', function (d) {
    return answerShown ? height - scaleY(d.share) : 0;
  });
  $answer__bars.selectAll('.answerBarLabel').attr('x', function (d) {
    return scaleX(d.levels) + scaleX.bandwidth() / 2;
  }).attr('y', function (d) {
    return scaleY(d.share) - 10;
  });
}

function brushMove() {
  if (!d3.event.sourceEvent) return; // prevents user from moving the bar entirely (but only after the first brush event has occurred)

  if (d3.event.sourceEvent.type === "brush") return;
  if (!d3.event.selection) return; // ignore empty selections
  // determine the new location of the end of the bar and map it to its value

  var newBarPos = d3.event.selection.map(scaleY.invert); // returns an array mapping the bottom and top locations of the bar to their scaleY values

  var newShare = Math.ceil(newBarPos[0]); // round to make the numbers nicer for the calculations below

  var brushedBar = d3.select(this).select('.selection'); //  gets the node of the bar that was brushed
  // brushedBar.datum().share = newShare;  // need to update the data bound to the bar in case user clicks the chart and the bar needs to be redrawn in its original position

  var brushedLevel = brushedBar.datum().levels;
  var oldShare = brushedBar.datum().share; // if user drags bar such that the sum of all the bars is greater than 100, prevent them from continuing to drag

  var remainder = d3.sum(guessData.filter(function (d) {
    return d.levels !== brushedLevel;
  }), function (d) {
    return d.share;
  });

  if (newShare + remainder > 100) {
    guessData[brushedLevel].share = 100 - remainder;
    d3.select(this).call($brush.move, function (d) {
      return [100 - remainder, 0].map(scaleY);
    }); // console.log(guessData);

    $instruction2.style('visibility', 'visible');
  } // else, update the dataset with the new value and snap the bar to the nearest integer
  else {
      guessData[brushedLevel].share = newShare;
      d3.select(this).call($brush.move, function (d) {
        return [newShare, 0].map(scaleY);
      }); // const sum = d3.sum(guessData, d => d.share);
    }

  updateWarningMsg();
}

function brushEnd() {
  if (!d3.event.sourceEvent) return; // prevents user from moving the bar entirely (but only after the first brush event has occurred)

  if (d3.event.sourceEvent.type === "brush") return;

  if (!d3.event.selection) {
    // in case user makes an empty selection by clicking, not dragging, on the chart, redraw bar at last known height so it doesn't completely disappear
    $bars.call($brush.move, function (d) {
      return [d.share, 0].map(scaleY);
    });
  }

  updateInterpretText();
}

function resizeBar() {
  var clickedY = d3.mouse(this)[1];
  d3.select(this.parentNode).call($brush.move, [clickedY, 0]);
}

function updateWarningMsg() {
  var sum = d3.sum(guessData, function (d) {
    return d.share;
  });
  var diff = 100 - Math.round(sum); // if diff < 1, activate the "Submit" button and hide the warning message

  if (Math.abs(diff) < 1) {
    var msg = "You must decrease a bar to increase another";
    $warningMsg.html(msg);
    $submitBtn.attr('aria-disabled', false);
    $instruction2.style('visibility', 'visible');
  } else {
    var _msg = "Keep going! <strong>".concat(diff, "%</strong> of families are still unaccounted");

    $warningMsg.html(_msg);
    $warningMsg.style('visibility', 'visible');
    $submitBtn.attr('aria-disabled', true);
    $instruction2.style('visibility', 'hidden');
  }
}

function updateInterpretText() {
  // figure out which scenario the user has selected and display appropriate message
  var interpretation = ''; // scenario 1: most families don't move or move very little (bars 0 and 1 > 50%)

  if (guessData[0].share + guessData[1].share > 50) {
    interpretation = "According to you, most families don't move or move very little.";
  } // scenario 2: most families move a lot (bars 3 and 4 > 50%)
  else if (guessData[3].share + guessData[4].share > 50) {
      interpretation = "According to you, most families move a lot.";
    } // scenario 3: some families move very little, some move a lot (bars at the ends are tall while middle bars are short)
    else if (guessData[2].share < 20) {
        interpretation = "According to you, some families move very little while others move a lot.";
      } // scenario 4: most families move a moderate amount (bar 2 > 50%)
      else if (guessData[2].share > 50) {
          interpretation = "According to you, most families move a moderate amount.";
        } // scenario 5 (default): roughly equal numbers move a lot as do those that move a little (all bars roughly equal height)
        else {
            interpretation = "According to you, roughly equal numbers of families move a lot as do those that move a little.";
          }

  $interpretText.text(interpretation);
} // $submitBtn.on('click', showAnswer);


function showAnswer() {
  $answer__vis.classed('noDisplay', false); // transition bars to be dotted outlines

  $guess__svg.selectAll('rect.selection').style('fill', 'none').style('stroke', '#124653').style('stroke-dasharray', '4'); // add overlay so user can't continue to drag bars

  $guess__svg.append('rect').attr('x', margin.left).attr('y', margin.top).attr('width', width).attr('height', height).style('fill', 'rgba(255, 255, 255, 0'); // make submit button inactive again

  $submitBtn.attr('aria-disabled', true); // animate bars in from zero and show labels after all bars finish appearing

  d3.selectAll('.answerBar').transition(1000).delay(function (d, i) {
    return i * 500;
  }).attr('y', function (d) {
    return scaleY(d.share);
  }).attr('height', function (d) {
    return height - scaleY(d.share);
  }).end().then(function () {
    return d3.selectAll('.answerBarLabel').style('opacity', 1);
  });
}

function init() {
  setup();
  $submitBtn.on('click', showAnswer);
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{}],"RZIL":[function(require,module,exports) {
var define;
"use strict";!function(e){"function"==typeof define&&define.amd?define(e):"undefined"!=typeof module&&module.exports?module.exports=e():window.enterView=e.call(this)}(function(){var e=function(e){function n(){E=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.msRequestAnimationFrame||function(e){return setTimeout(e,1e3/60)}}function t(){if(y&&"number"==typeof y){var e=Math.min(Math.max(0,y),1);return F-e*F}return F}function o(){var e=document.documentElement.clientHeight,n=window.innerHeight||0;F=Math.max(e,n)}function r(){L=!1;var e=t();M=M.filter(function(n){var t=n.getBoundingClientRect(),o=t.top,r=t.bottom,i=t.height,s=o<e,u=r<e;if(s&&!n.__ev_entered){if(m(n),n.__ev_progress=0,h(n,n.__ev_progress),q)return!1}else!s&&n.__ev_entered&&(n.__ev_progress=0,h(n,n.__ev_progress),g(n));if(s&&!u){var d=(e-o)/i;n.__ev_progress=Math.min(1,Math.max(0,d)),h(n,n.__ev_progress)}return s&&u&&1!==n.__ev_progress&&(n.__ev_progress=1,h(n,n.__ev_progress)),n.__ev_entered=s,!0}),M.length||window.removeEventListener("scroll",i,!0)}function i(){L||(L=!0,E(r))}function s(){o(),r()}function u(){o(),r()}function d(e){for(var n=e.length,t=[],o=0;o<n;o+=1)t.push(e[o]);return t}function f(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:document;return"string"==typeof e?d(n.querySelectorAll(e)):e instanceof NodeList?d(e):e instanceof Array?e:void 0}function c(){M=f(v)}function a(){window.addEventListener("resize",s,!0),window.addEventListener("scroll",i,!0),window.addEventListener("load",u,!0),s()}function _(){return v?(c(),M&&M.length?(n(),a(),void r()):(console.error("no selector elements found"),!1)):(console.error("must pass a selector"),!1)}var v=e.selector,l=e.enter,m=void 0===l?function(){}:l,w=e.exit,g=void 0===w?function(){}:w,p=e.progress,h=void 0===p?function(){}:p,x=e.offset,y=void 0===x?0:x,A=e.once,q=void 0!==A&&A,E=null,L=!1,M=[],F=0;_()};return e});
},{}],"xZJw":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = loadData;

/* global d3 */

/* usage
	import loadData from './load-data'
	
	loadData('file.csv').then(result => {
		console.log(result);
	}).catch(console.error);

	loadData(['file1.csv', 'file2.json]).then(result => {
		console.log(result);
	}).catch(console.error);
*/
function loadFile(file) {
  return new Promise(function (resolve, reject) {
    var ext = file.split('.').pop();
    if (ext === 'csv') d3.csv("assets/data/".concat(file)).then(resolve).catch(reject);else if (ext === 'json') d3.json("assets/data/".concat(file)).then(resolve).catch(reject);else reject(new Error("unsupported file type for: ".concat(file)));
  });
}

function loadData(files) {
  if (typeof files === 'string') return loadFile(files);
  var loads = files.map(loadFile);
  return Promise.all(loads);
}
},{}],"Gtgh":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _enterView = _interopRequireDefault(require("enter-view"));

var _loadData = _interopRequireDefault(require("./load-data"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var $section = d3.select('.familyLines');
var $family__container = $section.select('.family__figure');
var $canvas__container = $family__container.select('.canvasContainer');
var $familyHist__svg = $family__container.select('svg.familyBars_svg');
var $family_smallMultiples__container = $section.select('.family_smallMultiples__figure');
var $familyHist_white__svg = $family_smallMultiples__container.select('svg.familyBars_white_svg');
var $familyHist_black__svg = $family_smallMultiples__container.select('svg.familyBars_black_svg');
var $familyHist_latino__svg = $family_smallMultiples__container.select('svg.familyBars_latino_svg'); // const $familyHist_asian__svg = $family_smallMultiples__container.select('svg.familyBars_asian_svg');
// const $familyHist_multi__svg = $family_smallMultiples__container.select('svg.familyBars_multi_svg');
// const $familyHist_native__svg = $family_smallMultiples__container.select('svg.familyBars_native_svg');

var $replay__btn = $section.select('.replay');
var $skipToEnd__btn = $section.select('.skipToEnd'); // dimensions

var DPR = window.devicePixelRatio ? Math.min(window.devicePixelRatio, 2) : 1;
var margin = {
  top: 40,
  bottom: 24,
  left: 114,
  right: 5
};
var margin_hist = {
  left: 5,
  right: 55
};
var familyLines_width = 0;
var familyHist_width = 0;
var familyHist_sm_width = 0;
var height = 0;
var height_sm = 0;
var $canvas_bg;
var $context_bg;
var $canvas;
var $context;
var $familyHist__vis;
var $bar_group;
var $bars;
var $bar_labels; // parameters for line chart animation

var timer;
var tweenTimer;
var maxLines = 10; // max number of lines that should appear on the chart at any given time

var ms_slow = 500; // how much time should elapse before the next line is drawn during the slow phase of the animation

var ms_fast = 20; // how much time should elapse during the sped up phase of the animation
// animation will take: (30 * 1000) + (10 * 1000) + ((7857-10) * 20) = 196,940 ms or 3.28 min to run

var fam_num = 1;
var dataByFamily;
var totalLines; // scales

var quintileNames = ['Lower', 'Lower Middle', 'Middle', 'Upper Middle', 'Upper'];
var scaleX_line = d3.scaleLinear();
var scaleY_line = d3.scaleLinear().domain([0, 100]);
var scaleX_hist = d3.scaleLinear().domain([0, 20]);
var scaleX_hist_sm = d3.scaleLinear().domain([0, 0.3]);
var scaleX_hist_breakpoints = [100, 500, 1000, 5000, 10000, 20000, 30000, 43000];
var scaleX_hist_breakpoints_copy = scaleX_hist_breakpoints.slice();
var scaleY_hist = d3.scaleBand().domain(quintileNames);
var scaleY_hist_sm = d3.scaleBand().domain(quintileNames);
var colorScale = d3.scaleOrdinal().domain(quintileNames).range(['#FFBFBF', '#FF8850', '#FEE074', '#00A08F', '#124653']);
var line;
var commaFmt = d3.format(',.0f');
var pctFmt = d3.format('.0%'); // initial data for the histogram

var histData = [{
  quintile: 'Lower',
  n: 0
}, {
  quintile: 'Lower Middle',
  n: 0
}, {
  quintile: 'Middle',
  n: 0
}, {
  quintile: 'Upper Middle',
  n: 0
}, {
  quintile: 'Upper',
  n: 0
}];
var histData_white = [{
  quintile: 'Lower',
  n: 9109,
  pct: 0.08625457
}, {
  quintile: 'Lower Middle',
  n: 17855,
  pct: 0.16907183
}, {
  quintile: 'Middle',
  n: 26135,
  pct: 0.24747647
}, {
  quintile: 'Upper Middle',
  n: 28805,
  pct: 0.27275912
}, {
  quintile: 'Upper',
  n: 23702,
  pct: 0.22443801
}];
var histData_black = [{
  quintile: 'Lower',
  n: 12439,
  pct: 0.23273959
}, {
  quintile: 'Lower Middle',
  n: 14583,
  pct: 0.27285484
}, {
  quintile: 'Middle',
  n: 13305,
  pct: 0.24894286
}, {
  quintile: 'Upper Middle',
  n: 9156,
  pct: 0.17131310
}, {
  quintile: 'Upper',
  n: 3963,
  pct: 0.07414961
}];
var histData_latino = [{
  quintile: 'Lower',
  n: 807,
  pct: 0.1434157
}, {
  quintile: 'Lower Middle',
  n: 1444,
  pct: 0.2566199
}, {
  quintile: 'Middle',
  n: 1581,
  pct: 0.2809668
}, {
  quintile: 'Upper Middle',
  n: 1134,
  pct: 0.2015283
}, {
  quintile: 'Upper',
  n: 661,
  pct: 0.1174693
}]; // const histData_asian = [
//   { quintile: 'Lower', n: 55, pct: 0.07198953 },
//   { quintile: 'Lower Middle', n: 124, pct: 0.16230366 },
//   { quintile: 'Middle', n: 199, pct: 0.26047120 },
//   { quintile: 'Upper Middle', n: 167, pct: 0.21858639 },
//   { quintile: 'Upper', n: 219, pct: 0.28664921 },
// ];
// const histData_multi = [
//   { quintile: 'Lower', n: 418, pct: 0.1236686 },
//   { quintile: 'Lower Middle', n: 615, pct: 0.1819527 },
//   { quintile: 'Middle', n: 918, pct: 0.2715976 },
//   { quintile: 'Upper Middle', n: 851, pct: 0.2517751 },
//   { quintile: 'Upper', n: 578, pct: 0.1710059 },
// ];
// const histData_native = [
//   { quintile: 'Lower', n: 88, pct: 0.1959911 },
//   { quintile: 'Lower Middle', n: 95, pct: 0.2115813 },
//   { quintile: 'Middle', n: 114, pct: 0.2538976 },
//   { quintile: 'Upper Middle', n: 97, pct: 0.2160356 },
//   { quintile: 'Upper', n: 55, pct: 0.1224944 },
// ];

function setup() {
  // dimensions
  familyLines_width = ($canvas__container.node().getBoundingClientRect().width - margin.left - margin.right) * DPR;
  familyHist_width = ($familyHist__svg.node().getBoundingClientRect().width - margin_hist.left - margin_hist.right) * DPR;
  familyHist_sm_width = $familyHist_white__svg.node().getBoundingClientRect().width - margin_hist.left - margin_hist.right;
  height = ($canvas__container.node().getBoundingClientRect().height - margin.top - margin.bottom) * DPR;
  height_sm = familyHist_sm_width * 1.7 - margin.top - margin.bottom; // set up canvases - one for the background, one for the line

  $canvas_bg = $canvas__container.append('canvas').attr('class', 'background').attr('width', familyLines_width + (margin.left + margin.right) * DPR).attr('height', height + (margin.top + margin.bottom) * DPR).style('width', "".concat(familyLines_width / DPR + margin.left + margin.right, "px")).style('height', "".concat(height / DPR + margin.top + margin.bottom, "px"));
  $context_bg = $canvas_bg.node().getContext('2d');
  $canvas = $canvas__container.append('canvas').attr('class', 'line').attr('width', familyLines_width + (margin.left + margin.right) * DPR).attr('height', height + (margin.top + margin.bottom) * DPR).style('width', "".concat(familyLines_width / DPR + margin.left + margin.right, "px")).style('height', "".concat(height / DPR + margin.top + margin.bottom, "px"));
  $context = $canvas.node().getContext('2d'); // scales

  scaleX_line.range([margin.left * DPR, margin.left * DPR + familyLines_width]);
  scaleY_line.range([height + margin.top * DPR, margin.top * DPR]);
  scaleX_hist.range([0, familyHist_width / DPR]);
  scaleX_hist_sm.range([0, familyHist_sm_width]);
  scaleY_hist.range([height / DPR, 0]);
  scaleY_hist_sm.range([height_sm, 0]); // line generator

  line = d3.line().x(function (d) {
    return snapToNearestPoint(scaleX_line(d.year));
  }).y(function (d) {
    return snapToNearestPoint(scaleY_line(d.pctile));
  }).curve(d3.curveStepAfter).context($context);
  drawHistogram($familyHist__svg, histData, familyHist_width / DPR, height / DPR, scaleX_hist, scaleY_hist, false);
  drawHistogram($familyHist_white__svg, histData_white, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true);
  drawHistogram($familyHist_black__svg, histData_black, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true);
  drawHistogram($familyHist_latino__svg, histData_latino, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true); // drawHistogram($familyHist_asian__svg, histData_asian, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true);
  // drawHistogram($familyHist_multi__svg, histData_multi, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true);
  // drawHistogram($familyHist_native__svg, histData_native, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true);
}

function drawHistogram(svg, data, width, height, xScale, yScale, isSmallMultiple) {
  // set the xScale domain for each race small multiple individually
  // if(isSmallMultiple) {
  //   xScale.domain([0, d3.max(data, d => d.n)]);
  // }
  $familyHist__vis = svg.attr('width', width + margin_hist.left + margin_hist.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', "translate(".concat(margin_hist.left, ",").concat(margin.top, ")"));
  $bar_group = $familyHist__vis.selectAll('.bar_group').data(data).enter().append('g').attr('class', 'bar_group');
  $bars = $bar_group.append('rect').attr('class', 'bar').attr('x', 0).attr('y', function (d) {
    return yScale(d.quintile);
  }).attr('width', function (d) {
    return isSmallMultiple ? xScale(d.pct) : xScale(d.n);
  }).attr('height', yScale.bandwidth()).style('fill', function (d) {
    return colorScale(d.quintile);
  });
  $bar_labels = $bar_group.append('text').attr('class', 'label').attr('x', function (d) {
    return isSmallMultiple ? xScale(d.pct) + 5 : 5;
  }).attr('y', function (d) {
    return yScale(d.quintile) + yScale.bandwidth() / 2;
  }).attr('dy', '.5em').text(function (d) {
    return isSmallMultiple ? pctFmt(d.pct) : commaFmt(d.n);
  });

  if (!isSmallMultiple) {
    $familyHist__vis.append('g').attr('class', 'axis axis--x').attr('transform', "translate(0,".concat(height, ")")).call(d3.axisBottom(scaleX_hist).tickValues([0, 20]));
  }

  svg.append('text').attr('x', margin_hist.left).attr('y', '1em').text('Years in Each Quintile');
  svg.append('text').attr('x', margin_hist.left).attr('y', '2.3em').text('(across x families)');
}

function resize() {
  // get new dimensions of the container element
  familyLines_width = ($canvas__container.node().getBoundingClientRect().width - margin.left - margin.right) * DPR;
  familyHist_width = ($familyHist__svg.node().getBoundingClientRect().width - margin_hist.left - margin_hist.right) * DPR;
  familyHist_sm_width = $familyHist_white__svg.node().getBoundingClientRect().width - margin_hist.left - margin_hist.right;
  height = ($canvas__container.node().getBoundingClientRect().height - margin.top - margin.bottom) * DPR;
  height_sm = familyHist_sm_width * 1.7 - margin.top - margin.bottom; // update scales

  scaleX_line.range([margin.left * DPR, margin.left * DPR + familyLines_width]);
  scaleY_line.range([height + margin.top * DPR, margin.top * DPR]);
  scaleX_hist.range([0, familyHist_width / DPR]);
  scaleY_hist.range([height / DPR, 0]);
  scaleX_hist_sm.range([0, familyHist_sm_width]);
  scaleY_hist_sm.range([height_sm, 0]); // line generator

  line = d3.line().x(function (d) {
    return snapToNearestPoint(scaleX_line(d.year));
  }).y(function (d) {
    return snapToNearestPoint(scaleY_line(d.pctile));
  }).curve(d3.curveStepAfter).context($context); // resize canvases and svg

  $canvas_bg.attr('width', familyLines_width + (margin.left + margin.right) * DPR).attr('height', height + (margin.top + margin.bottom) * DPR).style('width', "".concat(familyLines_width / DPR + margin.left + margin.right, "px")).style('height', "".concat(height / DPR + margin.top + margin.bottom, "px"));
  $canvas.attr('width', familyLines_width + (margin.left + margin.right) * DPR).attr('height', height + (margin.top + margin.bottom) * DPR).style('width', "".concat(familyLines_width / DPR + margin.left + margin.right, "px")).style('height', "".concat(height / DPR + margin.top + margin.bottom, "px")); // clear current background canvas and redraw with new dimensions

  $context_bg.clearRect(0, 0, $canvas_bg.attr('width'), $canvas_bg.attr('height'));
  addQuintileBackground(); // update bar lengths and label placements in histograms

  resizeHistogram($familyHist__svg, histData, familyHist_width / DPR, height / DPR, scaleX_hist, scaleY_hist, false);
  resizeHistogram($familyHist_white__svg, histData_white, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true);
  resizeHistogram($familyHist_black__svg, histData_black, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true);
  resizeHistogram($familyHist_latino__svg, histData_latino, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true); // resizeHistogram($familyHist_asian__svg, histData_asian, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true);
  // resizeHistogram($familyHist_multi__svg, histData_multi, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true);
  // resizeHistogram($familyHist_native__svg, histData_native, familyHist_sm_width, height_sm, scaleX_hist_sm, scaleY_hist_sm, true);
}

function resizeHistogram(svg, data, width, height, xScale, yScale, isSmallMultiple) {
  // set the xScale domain for each race small multiple individually
  // if(isSmallMultiple) {
  //   xScale.domain([0, d3.max(data, d => d.n)]);
  // }
  // resize svg container
  var hist = svg.attr('width', width + margin_hist.left + margin_hist.right).attr('height', height + margin.top + margin.bottom);
  var bar_group = hist.selectAll('.bar_group');
  bar_group.select('.bar').attr('y', function (d) {
    return yScale(d.quintile);
  }).attr('width', function (d) {
    return isSmallMultiple ? xScale(d.pct) : xScale(d.n);
  }).attr('height', yScale.bandwidth());
  bar_group.select('.label').attr('x', function (d) {
    return isSmallMultiple ? xScale(d.pct) + 5 : xScale(d.n) + 5;
  }).attr('y', function (d) {
    return yScale(d.quintile) + yScale.bandwidth() / 2;
  }); // resize the x-axis for the non-small multiple histogram

  if (!isSmallMultiple) {
    $familyHist__svg.selectAll('.axis.axis--x').attr('transform', "translate(0,".concat(height, ")")).call(d3.axisBottom(scaleX_hist).tickValues([0, scaleX_hist_breakpoints[0]]));
  }
}

function drawFirstLine() {
  // loop through data, call canvas to draw incrementally to add next year of data to line
  // then update histogram
  var firstLineData = dataByFamily[0].values;
  var length = 0;
  drawSegment();

  function drawSegment() {
    if (length < firstLineData.length) {
      var t0 = length > 0 ? firstLineData[length - 1] : firstLineData[0];
      var t1 = firstLineData[length];
      var x0 = snapToNearestPoint(scaleX_line(t0.year));
      var x1 = snapToNearestPoint(scaleX_line(t1.year));
      var y0 = snapToNearestPoint(scaleY_line(t0.pctile));
      var y1 = snapToNearestPoint(scaleY_line(t1.pctile));
      var switchToY = (x1 - x0) / (x1 - x0 + Math.abs(y1 - y0)); // get proportion of time that should be spent animating x versus y by taking ratio of x length to total line segment length

      var last_x = x0;
      var last_y = y0;
      tweenTimer = d3.timer(function (elapsed) {
        var t = Math.min(1, elapsed / ms_slow);
        var next_x = x0 * (1 - t / switchToY) + x1 * (t / switchToY);
        var next_y = y0 * ((1 - t) / (1 - switchToY)) + y1 * ((t - switchToY) / (1 - switchToY));
        $context.beginPath(); // if t < proportion, only animate x from x0 to x1 (while y = y0)

        if (t < switchToY) {
          $context.moveTo(last_x, y0);
          $context.lineTo(next_x, y0);
          last_x = next_x;
          last_y = y0;
        } // else, if t > proportion, only animate y from y0 to y1 (while x = x1)
        else {
            if (last_x < x1 && next_x >= x1) {
              // if during the last t, the line didn't quite get to x1, complete the horizontal section first
              $context.moveTo(last_x, y0);
              $context.lineTo(x1, y0);
            }

            $context.moveTo(x1, last_y);
            $context.lineTo(x1, next_y);
            last_x = x1;
            last_y = next_y;
          }

        $context.lineWidth = 2;
        $context.strokeStyle = 'rgba(0, 0, 0, 1)';
        $context.stroke();

        if (t === 1) {
          tweenTimer.stop();
          drawSegment();
        }
      });
    }

    updateHistogram(firstLineData.slice(length, length + 1), ms_slow);
    length++;
  }
}

function animateLines() {
  tweenTimer.stop(); // make sure first line animation stops in case user navigates off the page

  if (fam_num < totalLines) {
    // if(fam_num < 100) {
    if (fam_num < maxLines) {
      animate(dataByFamily, fam_num, ms_slow);
      timer = setTimeout(animateLines, ms_slow);
    } else {
      animate(dataByFamily, fam_num, ms_fast);
      timer = setTimeout(animateLines, ms_fast);
    }
  }

  fam_num++;
}

function animate(data, fam_num, ms) {
  // animation function for the first few lines where multiple lines appear on the plot at once
  // when the next line is drawn, reduce the opacity of previously drawn line and remove the
  // line entirely when ten more lines are drawn afterwards
  $context.clearRect(0, 0, $canvas.attr('width'), $canvas.attr('height')); // addQuintileBackground();
  // for the first few lines, first fade out the nine previously drawn lines

  if (fam_num < maxLines) {
    for (var i = fam_num - 1; i >= 0; i--) {
      drawLine(data[i].values, 0.1);
    }
  }

  drawLine(data[fam_num].values, 1);
  updateHistogram(data[fam_num].values, ms);
}

function drawLine(data, opacity) {
  // given data, draws a line using canvas by feeding the data to d3's line generator
  $context.beginPath();
  line(data);
  $context.lineWidth = 2;
  $context.strokeStyle = "rgba(0, 0, 0, ".concat(opacity, ")");
  $context.stroke();
}

function addQuintileBackground() {
  // shades the part of the plot that corresponds to each quintile with that quintile's color
  // y-axis labels
  $context_bg.font = "".concat(14 * DPR, "px \"National 2 Narrow Web\"");
  $context_bg.fillStyle = '#828282';
  $context_bg.textAlign = 'end';
  $context_bg.textBaseline = 'bottom';
  $context_bg.fillText('Higher', 42 * DPR, (margin.top + 23) * DPR);
  $context_bg.fillText('income', 42 * DPR, (margin.top + 37) * DPR);
  $context_bg.fillText('Lower', 42 * DPR, (margin.top - 24) * DPR + height);
  $context_bg.fillText('income', 42 * DPR, (margin.top - 10) * DPR + height); // draw arrows

  $context_bg.beginPath();
  $context_bg.moveTo(37 * DPR, margin.top * DPR);
  $context_bg.lineTo(42 * DPR, (margin.top + 5) * DPR);
  $context_bg.lineTo(32 * DPR, (margin.top + 5) * DPR);
  $context_bg.fill();
  $context_bg.beginPath();
  $context_bg.moveTo(37 * DPR, margin.top * DPR + height);
  $context_bg.lineTo(42 * DPR, (margin.top - 5) * DPR + height);
  $context_bg.lineTo(32 * DPR, (margin.top - 5) * DPR + height);
  $context_bg.fill(); // x-axis labels

  $context_bg.textAlign = 'start';
  $context_bg.fillText('Income in first year', margin.left * DPR, margin.top * DPR + height + margin.bottom * DPR - 2);
  $context_bg.textAlign = 'end';
  $context_bg.fillText('Income in last year', margin.left * DPR + familyLines_width, margin.top * DPR + height + margin.bottom * DPR - 2); // $context.beginPath();
  // $context.moveTo(snapToNearestPoint(margin.left), margin.top + height);
  // $context.lineTo(snapToNearestPoint(margin.left), margin.top + height + 19);
  // $context.lineWidth = 1;
  // $context.strokeStyle = '#828282';
  // $context.stroke();
  // $context.beginPath();
  // $context.moveTo(
  //   snapToNearestPoint(margin.left + familyLines_width - 2),
  //   margin.top + height
  // );
  // $context.lineTo(
  //   snapToNearestPoint(margin.left + familyLines_width - 2),
  //   margin.top + height + 19
  // );
  // $context.lineWidth = 1;
  // $context.strokeStyle = '#828282';
  // $context.stroke();

  quintileNames.forEach(function (d, i) {
    var $gradient = $context_bg.createLinearGradient(margin.left * DPR, 0, $canvas_bg.attr('width'), 0);
    $gradient.addColorStop(0, 'white');
    $gradient.addColorStop(1, colorScale(d));
    $context_bg.fillStyle = $gradient;
    $context_bg.fillRect(margin.left * DPR, scaleY_line((i + 1) * 20), familyLines_width, height / 5);
  });
  var axisImage = new Image();
  axisImage.src = 'assets/images/familyLines_yAxis.png';

  axisImage.onload = function () {
    $context_bg.drawImage(axisImage, 50 * DPR, margin.top * DPR, height * 0.1, height);
  };
}

function updateHistogram(data, time) {
  // update histogram data
  updateHistData(data); // check if we need to update histogram's scaleX

  updateHistScaleX(); // update histogram bars and labels

  var bar_group = $familyHist__svg.selectAll('.bar_group');
  bar_group.data(histData);
  bar_group.selectAll('.bar').transition().delay(time).duration(time).attr('width', function (d) {
    return scaleX_hist(d.n);
  });
  bar_group.selectAll('.label').transition().delay(time).duration(time).attr('x', function (d) {
    return scaleX_hist(d.n) + 5;
  }).text(function (d) {
    return commaFmt(d.n);
  });
}

function updateHistScaleX() {
  // updates the ScaleX for the histogram when the number of observations exceeds the current domain bounds
  var dataMax = d3.max(histData, function (d) {
    return d.n;
  });
  var scale_current_max = scaleX_hist.domain()[1];

  if (dataMax > scale_current_max) {
    scaleX_hist.domain([0, scaleX_hist_breakpoints_copy[0]]);
    scaleX_hist_breakpoints_copy.shift();
    $familyHist__svg.selectAll('.axis.axis--x').transition().call(d3.axisBottom(scaleX_hist).tickValues(scaleX_hist.domain()));
  }
}

function updateHistData(data) {
  // updates the data used for the histogram (histData) with the frequencies from one additional family
  var countsObj = countFrequency(data);
  histData.forEach(function (d) {
    if (d.quintile === 'Lower') d.n += countsObj.Lower;else if (d.quintile == 'Lower Middle') d.n += countsObj['Lower Middle'];else if (d.quintile == 'Middle') d.n += countsObj.Middle;else if (d.quintile == 'Upper Middle') d.n += countsObj['Upper Middle'];else if (d.quintile == 'Upper') d.n += countsObj.Upper;
  });
}

function countFrequency(data) {
  // returns an object with the total number of occurrences of a quintile in the data
  // set up an object to hold the counts
  var quintileCountsObj = {};
  quintileNames.forEach(function (d) {
    return quintileCountsObj[d] = 0;
  }); // populate the object with frequencies

  data.forEach(function (d) {
    if (d.quintile === '1') quintileCountsObj.Lower++;else if (d.quintile === '2') quintileCountsObj['Lower Middle']++;else if (d.quintile === '3') quintileCountsObj.Middle++;else if (d.quintile === '4') quintileCountsObj['Upper Middle']++;else if (d.quintile === '5') quintileCountsObj.Upper++;
  });
  return quintileCountsObj;
}

function objToArray(obj) {
  // turns the object with quintile frequency counts into an array that d3 prefers
  var quintileArray = [];
  quintileArray = Object.keys(obj).map(function (key) {
    return {
      quintile: key,
      n: obj[key]
    };
  });
  return quintileArray;
}

function replay() {
  // cancel current timer and clear canvas
  tweenTimer.stop();
  clearTimeout(timer);
  $context.clearRect(0, 0, $canvas.attr('width'), $canvas.attr('height')); // addQuintileBackground();
  // reset histogram to zero

  scaleX_hist.domain([0, 20]);
  scaleX_hist_breakpoints_copy = scaleX_hist_breakpoints.slice();
  histData = [{
    quintile: 'Lower',
    n: 0
  }, {
    quintile: 'Lower Middle',
    n: 0
  }, {
    quintile: 'Middle',
    n: 0
  }, {
    quintile: 'Upper Middle',
    n: 0
  }, {
    quintile: 'Upper',
    n: 0
  }];
  $familyHist__svg.selectAll('.axis.axis--x').transition().call(d3.axisBottom(scaleX_hist).tickValues([0, 20]));
  var bar_group = $familyHist__svg.selectAll('.bar_group');
  bar_group.data(histData);
  bar_group.select('.bar').transition().duration(500).attr('width', function (d) {
    return scaleX_hist(d.n);
  });
  bar_group.select('.label').transition().duration(500).attr('x', 5).text(function (d) {
    return commaFmt(d.n);
  }); // restart animation

  fam_num = 1;
  var firstLineLength = dataByFamily[0].values.length;
  drawFirstLine();
  timer = setTimeout(animateLines, firstLineLength * ms_slow);
}

function showEnd(countsArray) {
  // when user clicks the button to skip the animation, cancel the timer, clear canvas
  // (but redraw background) and show the histogram with data from all families
  tweenTimer.stop();
  clearTimeout(timer);
  $context.clearRect(0, 0, $canvas.attr('width'), $canvas.attr('height')); // addQuintileBackground();

  scaleX_hist.domain([0, scaleX_hist_breakpoints[scaleX_hist_breakpoints.length - 1]]);
  $familyHist__svg.selectAll('.axis.axis--x').transition().call(d3.axisBottom(scaleX_hist).tickValues(scaleX_hist.domain()));
  var bar_group = $familyHist__svg.selectAll('.bar_group');
  bar_group.data(countsArray);
  bar_group.select('.bar').transition().duration(500).attr('width', function (d) {
    return scaleX_hist(d.n);
  });
  bar_group.select('.label').transition().duration(500).attr('x', function (d) {
    return scaleX_hist(d.n) + 5;
  }).text(function (d) {
    return commaFmt(d.n);
  });
}

function snapToNearestPoint(value) {
  // rounds pixel value to nearest half point
  // needed to improve sharpness of lines in canvas
  return Math.round(value);
}
/*
function wrap(text, width) {
  text.each(function() {
    const text = d3.select(this);
    const words = text
      .text()
      .split(/\s+/)
      .reverse();
    let word;
    let line = [];
    let lineNumber = 0;
    const lineHeight = 1.1; // ems
    const y = text.attr('y');
    const dy = 0.3;
    let tspan = text
      .text(null)
      .append('tspan')
      .attr('x', 0)
      .attr('y', y)
      .attr('dy', `${dy}em`);
    while ((word = words.pop())) {
      line.push(word);
      tspan.text(line.join(' '));
      if (tspan.node().getComputedTextLength() > width) {
        line.pop();
        tspan.text(line.join(' '));
        line = [word];
        tspan = text
          .append('tspan')
          .attr('x', 0)
          .attr('y', y)
          .attr('dy', `${++lineNumber * lineHeight + dy}em`)
          .text(word);
      }
    }
  });
}
*/


function init() {
  setup();
  (0, _loadData.default)('line_chart_data.csv').then(function (result) {
    // nest data because that's the structure d3 needs to make line charts
    dataByFamily = d3.nest().key(function (d) {
      return d.id;
    }).entries(result);
    totalLines = dataByFamily.length; // set scale domains

    scaleX_line.domain([0, d3.max(result, function (d) {
      return +d.year;
    })]).nice();
    var counts = countFrequency(result);
    var countsArray = objToArray(counts); // append axis for debugging purposes
    // $familyLines__vis.append('g')
    //  .attr('class', 'axis axis--y')
    //  .call(d3.axisLeft(scaleY_line));
    // $familyLines__vis.append('g')
    //  .attr('class', 'axis axis--x')
    //  .attr('transform', 'translate(0,' + height + ')')
    //  .call(d3.axisBottom(scaleX_line));

    addQuintileBackground();
    var firstLineLength = dataByFamily[0].values.length;
    (0, _enterView.default)({
      selector: '.family__figure',
      offset: 0.5,
      enter: function enter() {
        drawFirstLine();
        timer = setTimeout(animateLines, (firstLineLength + 1) * ms_slow); // timer = setTimeout(animateLines, 0);
      },
      once: true
    }); // event handlers

    $replay__btn.on('click', function () {
      return replay();
    });
    $skipToEnd__btn.on('click', function () {
      return showEnd(countsArray);
    });
  }).catch(console.error);
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"enter-view":"RZIL","./load-data":"xZJw"}],"TAPd":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _guessMovement = _interopRequireDefault(require("./guessMovement"));

var _familyLines = _interopRequireDefault(require("./familyLines"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
function resize() {
  console.log('Resize!');

  _guessMovement.default.resize();

  _familyLines.default.resize();
}

function init() {
  console.log('Make something awesome!');

  _guessMovement.default.init();

  _familyLines.default.init();
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"./guessMovement":"WtE3","./familyLines":"Gtgh"}],"v9Q8":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var fallbackData = [{
  image: "2018_02_stand-up",
  url: "2018/02/stand-up",
  hed: "The Structure of Stand-Up Comedy"
}, {
  image: "2018_04_birthday-paradox",
  url: "2018/04/birthday-paradox",
  hed: "The Birthday Paradox Experiment"
}, {
  image: "2018_11_boy-bands",
  url: "2018/11/boy-bands",
  hed: "Internet Boy Band Database"
}, {
  image: "2018_08_pockets",
  url: "2018/08/pockets",
  hed: "Women’s Pockets are Inferior"
}];
var storyData = null;

function loadJS(src, cb) {
  var ref = document.getElementsByTagName("script")[0];
  var script = document.createElement("script");
  script.src = src;
  script.async = true;
  ref.parentNode.insertBefore(script, ref);

  if (cb && typeof cb === "function") {
    script.onload = cb;
  }

  return script;
}

function loadStories(cb) {
  var request = new XMLHttpRequest();
  var v = Date.now();
  var url = "https://pudding.cool/assets/data/stories.json?v=".concat(v);
  request.open("GET", url, true);

  request.onload = function () {
    if (request.status >= 200 && request.status < 400) {
      var data = JSON.parse(request.responseText);
      cb(data);
    } else cb(fallbackData);
  };

  request.onerror = function () {
    return cb(fallbackData);
  };

  request.send();
}

function createLink(d) {
  return "\n\t<a class='footer-recirc__article' href='https://pudding.cool/".concat(d.url, "' target='_blank' rel='noopener'>\n\t\t<img class='article__img' src='https://pudding.cool/common/assets/thumbnails/640/").concat(d.image, ".jpg' alt='").concat(d.hed, "'>\n\t\t<p class='article__headline'>").concat(d.hed, "</p>\n\t</a>\n\t");
}

function recircHTML() {
  var url = window.location.href;
  var html = storyData.filter(function (d) {
    return !url.includes(d.url);
  }).slice(0, 4).map(createLink).join("");
  d3.select(".pudding-footer .footer-recirc__articles").html(html);
}

function init() {
  loadStories(function (data) {
    storyData = data;
    recircHTML();
  });
}

var _default = {
  init: init
};
exports.default = _default;
},{}],"epB2":[function(require,module,exports) {
"use strict";

var _lodash = _interopRequireDefault(require("lodash.debounce"));

var _isMobile = _interopRequireDefault(require("./utils/is-mobile"));

var _linkFix = _interopRequireDefault(require("./utils/link-fix"));

var _graphic = _interopRequireDefault(require("./graphic"));

var _footer = _interopRequireDefault(require("./footer"));

var _guessMovement = _interopRequireDefault(require("./guessMovement.js"));

var _familyLines = _interopRequireDefault(require("./familyLines.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
var $body = d3.select("body");
var previousWidth = 0;

function resize() {
  // only do resize on width changes, not height
  // (remove the conditional if you want to trigger on height change)
  var width = $body.node().offsetWidth;

  if (previousWidth !== width) {
    previousWidth = width;

    _graphic.default.resize();
  }
}

function setupStickyHeader() {
  var $header = $body.select("header");

  if ($header.classed("is-sticky")) {
    var $menu = $body.select(".header__menu");
    var $toggle = $body.select(".header__toggle");
    $toggle.on("click", function () {
      var visible = $menu.classed("is-visible");
      $menu.classed("is-visible", !visible);
      $toggle.classed("is-visible", !visible);
    });
  }
}

function init() {
  // adds rel="noopener" to all target="_blank" links
  (0, _linkFix.default)(); // add mobile class to body tag

  $body.classed("is-mobile", _isMobile.default.any()); // setup resize event

  window.addEventListener("resize", (0, _lodash.default)(resize, 150)); // setup sticky header menu

  setupStickyHeader(); // kick off graphic code

  _graphic.default.init(); // load footer stories
  // footer.init();

}

init();
},{"lodash.debounce":"or4r","./utils/is-mobile":"WEtf","./utils/link-fix":"U9xJ","./graphic":"TAPd","./footer":"v9Q8","./guessMovement.js":"WtE3","./familyLines.js":"Gtgh"}]},{},["epB2"], null)
//# sourceMappingURL=/main.js.map